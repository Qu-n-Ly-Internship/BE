package com.example.be.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import java.io.IOException;

public class CustomAuthHandlers {

    // Khi chưa login (401)
    public static class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {
        @Override
        public void commence(HttpServletRequest request, HttpServletResponse response,
                org.springframework.security.core.AuthenticationException authException) throws IOException {
            System.out.println("🚨 Unauthorized request: " + request.getRequestURI());
            response.sendRedirect("/login"); // hoặc trả về JSON tùy FE
        }
    }

    // Khi login rồi nhưng không có quyền (403)
    public static class CustomAccessDeniedHandler implements AccessDeniedHandler {
        @Override
        public void handle(HttpServletRequest request, HttpServletResponse response,
                org.springframework.security.access.AccessDeniedException accessDeniedException) throws IOException {
            System.out.println("🚫 Forbidden request: " + request.getRequestURI());
            response.sendRedirect("/login");
        }
    }
}