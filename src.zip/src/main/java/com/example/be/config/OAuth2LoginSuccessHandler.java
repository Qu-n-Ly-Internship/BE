package com.example.be.config;

import java.io.IOException;
import com.example.be.service.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.example.be.entity.User;
import com.example.be.repository.UserRepository;
import com.example.be.service.AuthService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class OAuth2LoginSuccessHandler implements AuthenticationSuccessHandler {

        private final JwtService jwtService;
        private final AuthService authService;

        @Override
        public void onAuthenticationSuccess(HttpServletRequest request,
                        HttpServletResponse response,
                        Authentication authentication) throws IOException {
                org.springframework.security.oauth2.core.user.OAuth2User oAuth2User = (org.springframework.security.oauth2.core.user.OAuth2User) authentication
                                .getPrincipal();

                User user = authService.processOAuthPostLogin(oAuth2User);

                // Tạo JWT
                String token = jwtService.generateToken(user.getEmail());

                // Redirect về FE kèm token
                String redirectUrl = "http://localhost:5173/oauth2/callback?token=" + token;
                response.sendRedirect(redirectUrl);
        }
}
